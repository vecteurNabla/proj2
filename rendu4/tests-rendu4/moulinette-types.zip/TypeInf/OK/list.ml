let cons x l = x::l in
    cons 3 [4]
      
