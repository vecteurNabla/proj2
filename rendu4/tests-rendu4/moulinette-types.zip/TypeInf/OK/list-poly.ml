let a = [] in
    let b = [] in
    let l = a::b in
    prInt 12
      
