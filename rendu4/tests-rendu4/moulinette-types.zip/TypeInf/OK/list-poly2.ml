let a = [] in
let x = (fun x -> x)::a in
let y = 124::a in
    prInt 12
      
