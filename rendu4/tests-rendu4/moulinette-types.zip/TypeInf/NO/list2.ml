let f x l = x::l in
    f [4] [5]
      
