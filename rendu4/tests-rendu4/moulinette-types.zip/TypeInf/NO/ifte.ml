if 3>0 then 5 else (fun x -> 4)
                     
