if 5>(fun x -> x+1) then 3 else 2
                   
