(*** Un évaluateur de [miniML] ***)

module type ENV =
  sig
    exception Unbound_Variable
    type 'a env
    val empty_env : 'a env
    val get_env : 'a env -> string -> 'a
    val add_env : 'a env -> string -> 'a -> 'a env
    val unbind : 'a env -> string -> 'a env
  end
;;    

module EnvList : ENV =
  struct
    exception Unbound_Variable
    ;;
    
    type 'a env = (string * 'a) list
    ;;

    let empty_env = []
    ;;

    let rec get_env e s = match e with
      | [] -> raise Unbound_Variable
      | (str, x)::r -> if str = s then x else
                        get_env r s
    ;;

    let add_env e s x =
      (s, x)::e
    ;;
    let rec unbind e s = match e with
      | [] -> []
      | (str, x)::r -> if s = str then
                        unbind r s
                      else
                        (str, x)::(unbind r s)
  end
;;

module EnvFun : ENV =
  struct
    exception Unbound_Variable
    ;;
    
    type 'a env = string -> 'a
    ;;

    let empty_env = fun s -> raise Unbound_Variable
    ;;

    let get_env e s = (e s)
    ;;

    let add_env e s x =
      fun t -> if t = s then x else (e t)
    ;;
    
    let unbind e s =
      fun t -> if t = s then raise Unbound_Variable
            else (e t)
  end;;

open EnvFun

(* -------------------------------------- *)

module type MEM =
  sig
    type address
    type 'a mem
    val empty_mem : unit -> 'a mem
    val get_mem : 'a mem -> address -> 'a
    val set_mem : 'a mem -> address -> 'a -> unit
    val alloc_mem : 'a mem -> 'a -> address
  end
;;


module MemHash : MEM =
  struct
    type address = int
    ;;

    type 'a mem = (address, 'a) Hashtbl.t
    ;;

    let empty_mem () = Hashtbl.create 612
    ;;

    let get_mem = Hashtbl.find
    ;;
    
    let set_mem = Hashtbl.add
    ;;

    let alloc_mem m x =
      let a = Hashtbl.length m in
      set_mem m a x; a
    ;;
  end
;;
    
open MemHash
   
(* -------------------------------------- *)

type expr =
  (* Arith *)
  | TInt of int                    (* i *)
  | TAdd of expr * expr            (* e1 + e2 *)
  | TSub of expr * expr            (* e1 - e2 *)
  | TMul of expr * expr            (* e1 * e2 *)
  | TDiv of expr * expr            (* e1 / e2 *)
  (* Bool *)
  | TBoo of bool                   (* ⊤/⊥ *)
  | TLeq of expr * expr            (* e1 <= e2 *)
  (* Contrôle *)
  | TIte of expr * expr * expr     (* if e1 then e2 else e3 *)
  (* Cœur *)        
  | TLet of string * expr * expr   (* let x = e1 in e2 *)
  | TVar of string                 (* x *)
  | TFun of string * expr          (* fun x -> e *)
  | TApp of expr * expr            (* e1 e2 *)
  | TRec of string * string * expr * expr (* let rec f x = e1 in e2 *)
  (* Fonctions impératives *)       
  | TUnit                          (* () *)
  | TSeq of expr * expr            (* e1; e2 *)
  | TRef of expr                   (* ref e *)
  | TAff of expr * expr            (* e1 := e2 *)
  | TDer of expr                   (* !e *)
;;

type value =
  | VInt of int
  | VFun of string * value ref env * expr 
  | VRec of string * string * value ref env * expr (* pour le pretty-printing *)
  | VUnit
  | VRef of address
  | VBoo of bool
;;
(* On a pris la liberté d'utiliser des [value ref env]. Cela permet
  de modifier les bindings dans les environements, sans devoir en
  renvoyer un nouveau. Utile pour la récursion. On se garde
  d'utiliser cette fonctionnalité ailleurs. *)

(* -------------------------------------- *)

exception Div_by_Zero
;;

exception Ill_typed_expr
;;

(* -------------------------------------- *)

(* Des opérateurs utiles. "Déstructurent" les valeurs *)

let ( !. ) v = match v with
  | VInt(i) -> i
  | _ -> raise Ill_typed_expr
;;

let ( ?. ) v = match v with
  | VFun(s, en, e) -> (s, en, e)
  | VRec(s, f, en, e) -> (s, en, e)
  | _ -> raise Ill_typed_expr
;;

let ( !! ) v = match v with
  | VRef(a) -> a
  | _ -> raise Ill_typed_expr
;;

(* Merlin n'a pas l'air d'aimer cet opérateur, mais OCaml l'accepte… *)
let ( ?? ) v = match v with
  | VBoo(b) -> b
  | _ -> raise Ill_typed_expr

(* -------------------------------------- *)

let rec eval en ex m = match ex with
  (* Arith *)
  | TInt(i) -> VInt(i)
  | TAdd(e, e') -> let i1 = !.(eval en e m) in (* Évaluation gauche-droite *)
                  let i2 = !.(eval en e' m) in (* On rejette si addition d'autre *)
                  VInt(i1 + i2)                (* chose que des int (via !.) *)
  | TSub(e, e') -> let i1 = !.(eval en e m) in
                  let i2 = !.(eval en e' m) in
                  VInt(i1 - i2)
  | TMul(e, e') -> let i1 = !.(eval en e m) in  (* idem *)
                  let i2 = !.(eval en e' m) in
                  VInt(i1 * i2)
  | TDiv(e, e') -> let deno = !.(eval en e' m) in (* On calcule d'abord le déno pour *)
                  if deno = 0 then               (* ne pas avoir à calculer le num pour rien *)
                    raise Div_by_Zero            
                  else
                    VInt(!.(eval en e m) / deno)
  (* Bool *)
  | TBoo(b) -> VBoo(b)
  | TLeq(e, e') -> let i1 = !.(eval en e m) in 
                  let i2 = !.(eval en e' m) in
                  VBoo(i1 <= i2)
  | TIte(eb, e1, e2) -> let b = ??(eval en eb m) in
                       if b then eval en e1 m else eval en e2 m
  (* Fonct *)
  | TLet(s, e, e') -> eval (add_env en s (ref (eval en e m))) e' m (* OCaml évalue e en premier *)
  | TVar(s) -> !(get_env en s)
  | TFun(s, e) -> VFun(s, en, e)
  | TApp(e, e') -> let s, en', ex = ?.(eval en e m) in           (* On évalue gauche-droite pour rejetter *)
                  eval (add_env en' s (ref(eval en e' m))) ex m (* si on applique autre chose qu'une fun *)
  | TRec(f, x, e, e') ->                                         
     let en' = add_env en f (ref (VRec (x, f, en, e))) in          (* On associe d'abord à f une valeur bidon *)
     (
       (get_env en' f) := VRec(x, f, en', e);                       (* Pour la modifier ensuite *)
       eval en' e' m
     )
  (* Imp *)
  | TUnit -> VUnit
  | TSeq(e, e') -> (
    ignore(eval en e m);        (* Comme en OCaml, si e ne s'évalue pas en unit, c'est *)
    eval en e' m                (* tout de même correct *)
  )
  | TRef(e) -> let ex = eval en e m in
              let a = alloc_mem m ex in
              VRef(a)
  | TAff(e, e') -> let r = !!(eval en e m) in (* Comme pour l'app, si e n'est pas une ref, *)
                  let v = eval en e' m in    (* on rejette *)
                  (
                    set_mem m r v;
                    VUnit
                  )
  | TDer(e) -> let r = !!(eval en e m) in (* Comme pour l'affectation *)
              get_mem m r
;;
                  
let rec eval_count en e m =
  let num = ref 0 in
  let rec aux e = match e with
    (* Arith *)
  | TInt(i) -> VInt i
  | TAdd(e, e') -> let i1 = !.(eval_count en e m) in 
                  let i2 = !.(eval_count en e' m) in
                  VInt(i1 + i2)
  | TSub(e, e') -> let i1 = !.(eval_count en e m) in
                  let i2 = !.(eval_count en e' m) in
                  VInt(i1 - i2)
  | TMul(e, e') -> let i1 = !.(eval_count en e m) in
                  let i2 = !.(eval_count en e' m) in
                  VInt(i1 * i2)
  | TDiv(e, e') -> let deno = !.(eval_count en e' m) in
                  (
                    incr num;
                    if deno = 0 then
                      raise Div_by_Zero
                    else
                      VInt(!.(eval_count en e m) / deno)
                  )
  (* Bool *)
  | TBoo(b) -> VBoo(b)
  | TLeq(e, e') -> let i1 = !.(eval_count en e m) in 
                  let i2 = !.(eval_count en e' m) in
                  VBoo(i1 <= i2)
  | TIte(eb, e1, e2) -> let b = ??(eval_count en eb m) in
                       if b then eval_count en e1 m else eval_count en e2 m
  (* Fonct *)
  | TLet(s, e, e') -> eval_count (add_env en s (ref (eval_count en e m))) e' m
  | TVar(s) -> !(get_env en s)
  | TFun(s, e) -> VFun(s, en, e)
  | TApp(e, e') -> let s, en', ex = ?.(eval_count en e m) in
                  eval_count (add_env en' s (ref (eval_count en e' m))) ex m
  | TRec(f, x, e, e') ->
     let en' = add_env en f (ref (VRec (x, f, en, e))) in
     (
       (get_env en' f) := VRec(x, f, en', e);
       eval_count en' e' m
     )
  (* Imp *)
  | TUnit -> VUnit
  | TSeq(e, e') -> (
    ignore(eval_count en e m);
    eval_count en e' m
  )
  | TRef(e) -> let ex = eval_count en e m in
              let a = alloc_mem m ex in
              VRef(a)
  | TAff(e, e') -> let r = eval_count en e m in
                  let v = eval_count en e' m in
                  (
                    set_mem m !!r v;
                    VUnit
                  )
  | TDer(e) -> let r = eval_count en e m in
              get_mem m !!r
  in
  let i = aux e in
  print_int !num;
  print_newline ();
  i
;;
