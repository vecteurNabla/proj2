open Format
open Main
open Main.EnvFun
open Main.MemHash
open MiniMLParser
open MiniMLLexer



(*-----------------------------*)
(* Input *)

(**
   val read_input : unit -> Main.expr
   [read_input ()] lit une entrée dans un fichier fourni en argument,
   ou sur l'entrée standard, tente de l'interpréter comme une expression.
 *)
let read_input () =
    let ic = try
        open_in Sys.argv.(1)
      with _ ->
        stdin
    in
  let s = ref "" in
  (
    try
      while true do
        s := !s ^ " " ^ input_line ic (* Pad the lines with spaces *)
      done
    with End_of_file ->
      close_in ic
  );
  expr1 lex (Lexing.from_string !s)

       

(*-----------------------------*)
(* Pretty-printing *)
   
(** Formatters pour différents types d'objets *)
  
let ident ppf s = fprintf ppf "%s" s
let intg ppf s = fprintf ppf "%d" s
let kwd ppf s = fprintf ppf "%s" s;;

(**
   val print_val Format.formatter -> Main.value
       -> Main.value Main.MemHash.mem
   Il faut passer la mémoire du programme si l'expression se réduit en
   une référence. Permet d'imprimer sur la sortie standard une
   valeur, sans couper des expressions en 2.
   Comme il n'y a pas d'évaluation partielle, si l'expression se
   réduit à une fonction, on doit connaître son environement, afin de
   pouvoir afficher correctement quelque chose comme:
   [let y = 1 in fun x -> x+ y]
   Cela se réduit en [fun x -> x + y], avec {y=1} comme environement.
   On veut donc pouvoir afficher [fun x -> x + 1]. Cela entraîne un
   problème, dans les expressions de type
   [let y = 42 in fun x -> fun y -> y + x]
   Ici, y dans le corps de la fonction n'est pas le y lié à *la
   réponse*, d'où l'ajout d'une fonction [unbind] à la signature des environements
 *)
let print_val ppf s m =
let rec pr_expr en ppf = function
  (* Arith *)
  | TInt(i) -> fprintf ppf "%a" intg i
  | TAdd(e1, e2) -> fprintf ppf "@[%a + %a@]" (pr_expr en) e1 (pr_expr en) e2
  | TSub(e1, e2) -> fprintf ppf "@[%a - %a@]" (pr_expr en) e1 (pr_expr en) e2
  | TMul(e1, e2) -> fprintf ppf "@[%a * %a@]" (pr_expr en) e1 (pr_expr en) e2
  | TDiv(e1, e2) -> fprintf ppf "@[%a / %a@]" (pr_expr en) e1 (pr_expr en) e2
  (* Bool *)
  | TBoo(b) -> fprintf ppf "%a" pr_val (VBoo(b))
  | TLeq(e1, e2) -> fprintf ppf "@[%a ≤ %a@]" (pr_expr en) e1 (pr_expr en) e2
  (* Control *)
  | TIte(eb, e1, e2) -> fprintf ppf "@[<1>%a %a %a@, %a@;<0 -2> %a @, %a@]"
                         kwd "if" (pr_expr en) eb kwd "then" (pr_expr en)
                         e1
                         kwd "else" (pr_expr en) e2
  (* Core *)
  | TVar(s) -> (
    try
      fprintf ppf "@[(%a:@ %a)@]" ident s pr_val !(get_env en s)
    with _ ->
      fprintf ppf "%a" ident s
  )
  | TFun(x, e) -> fprintf ppf "@[(%a)@]" pr_val (VFun(x, (unbind en x), e))
  | TLet(x, e1, e2) -> let en' = unbind en x in
     fprintf ppf "@[<1>%a %a =@ %a %a@;<0 -2> %a@]" kwd "let"
       ident x (pr_expr en') e1 kwd "in" (pr_expr en) e2
  | TRec(f, x, e, e') -> let en' = unbind (unbind en x) f in
                        fprintf ppf
                          "@[<1> %a %a %a %a =@, %a %a@;<0 -2> %a@]"
                          kwd "let" kwd "rec" ident f ident x
                          (pr_expr en') e
                        kwd "in" (pr_expr en) e'
  | TApp(e1, e2) -> fprintf ppf "@[%a@ (%a)@]" (pr_expr en) e1 (pr_expr en) e2
  (* Imp *)
  | TSeq(e1, e2) -> fprintf ppf "@[%a;@ @,%a@]" (pr_expr en) e1 (pr_expr en) e2
  | TUnit -> fprintf ppf "%a" kwd "()"
  | TRef(e) -> fprintf ppf "@[%a (%a)@]" kwd "ref" (pr_expr en) e
  | TAff(e1, e2) -> fprintf ppf "@[%a ⇐ %a@]" (pr_expr en) e1 (pr_expr en) e2
  | TDer(e) -> fprintf ppf "!%a" (pr_expr en) e
and pr_val ppf = function
  | VFun(x, en, e) ->
     fprintf ppf "@[<1>%a %a %a@, %a@]"
       kwd "λ" ident x kwd "→" (pr_expr (unbind en x)) e
  | VRec(x, f, en, e) ->
     fprintf ppf "@[<1>%a : %a %a %a@, %a@]"
       ident f kwd "λ" ident x kwd "→"
       (pr_expr (unbind (unbind en f) x)) e
  | VInt(i) ->
     fprintf ppf "%a" intg i
  | VUnit -> fprintf ppf "%a" kwd "()"
  | VRef(a) -> fprintf ppf "%a {contents : %a}" kwd "ref" pr_val
                (get_mem m a)
  | VBoo(b) -> fprintf ppf "%a" kwd (if b then "⊤" else "⊥")
in pr_val ppf s

              
(*-----------------------------*)
(* Main *)

let _ =
  let m = (empty_mem ()) in
  let v = eval empty_env (read_input ()) m in
  print_val std_formatter v m;
  print_newline ();
  exit 0
