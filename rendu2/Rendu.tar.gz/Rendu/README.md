```
'##::::'##:'####:'##::: ##:'####:'##::::'##:'##:::::::
 ###::'###:. ##:: ###:: ##:. ##:: ###::'###: ##:::::::
 ####'####:: ##:: ####: ##:: ##:: ####'####: ##:::::::
 ## ### ##:: ##:: ## ## ##:: ##:: ## ### ##: ##:::::::
 ##. #: ##:: ##:: ##. ####:: ##:: ##. #: ##: ##:::::::
 ##:.:: ##:: ##:: ##:. ###:: ##:: ##:.:: ##: ##:::::::
 ##:::: ##:'####: ##::. ##:'####: ##:::: ##: ########:
..:::::..::....::..::::..::....::..:::::..::........::
```
Texte ascii réalisé avec [figlet](http://www.figlet.org)


Un petit langage de programmation fonctionnel, inspiré des langages
ML. Le langage `miniML` implémente la sous-partie des expressions
OCaml formée par
```
e ::= k | -k | (e)
	| e + e | e - e | e * e | e / e 
	| let var {x₁ … xₙ} = e in e | let rec f x₁ … xₙ = e in e
	| fun var -> e | e e
	| true | false | e <= e | if e then e else e
	| ref e | e := e | !e | e; e | ()
```
Les identifiants doivent commencer par une lettre, et sont composés de
lettres, chiffres, underscores et apostrophes (reconnus par `[a-zA-Z][a-zA-Z0-9_']*`)

Compris dans cette archive :
- Les sources de `miniml`, un évaluateur d'expressions `miniML`
- Un makefile, pour compiler tout ça
- `agrud.el`, source de agrud-mode, un mode majeur d'emacs conçu
pour éditer des fichiers `miniML`, auxquels on aura affecté
l'extension `.mule`


Pour installer `miniml`:
```
$ make
```
puis
```
$ sudo make install
```
(Vérifiez que la variable INSTALL_PATH du Makefile est bien définie
vers un endroit de votre PATH, sinon ça n'a pas grand intérêt)

`miniml` lit sur son entrée standard, ou bien dans un fichier donné en
argument, et imprime sur la sortie standard la forme la plus réduite
de l'expression donnée en entrée (un valeur).


Pour profiter d'un environement d'édition inégalé pour le langage
`miniml` : depuis emacs
```
M-x load-file RET /path/to/the/agrud.el
```
ou, vous pouvez ajouter à votre fichier de configuration (généralement
`~/.emacs` ou `~/.emacs.d/init.el`) :
```
(load "/path/to/the/agrud.el")
```

Tout fichier avec l'extension `.mule` s'ouvre désormais avec le mode
majeur `agrud-mode`
`C-c C-c` évalue le buffer avec `miniml` (nécessite d'avoir installé
`miniml`), la sortie sera affichée dans le minibuffer, ou dans un
buffer `*Shell Command Output*` si trop grosse.
